/*
 * CumulocityPlatform.cpp
 *
 * Created on: Jan 2, 2013
 * Authors: Adam Pierzchała
 *          Oliver Stache
 */

#include "CumulocityPlatform.h"

const char* CUMULOCITY_ARDUINO_TYPE = "Arduino";
static const char* CUMULOCITY_CT_MANAGED_OBJECT_09 = "application";//"/vnd.com.nsn.cumulocity.managedObject+json;ver=0.9;charset=UTF-8";

char* HttpResponse::getRequestedValue() {
    return bufferForValue;
}

void HttpResponse::readHttpCode() {
    char buff[20];
    buff[19] = '\0';
    // read HTTP code
    char c;
    int i=0;
    do {
        c = gsm.read();
        if(c > 0)
            buff[i++] = c;
    } while(i < 19 && buff[i-1] != '\n');

    // rfc2616:
    // Status-Line = HTTP-Version SP Status-Code SP Reason-Phrase CRLF
    char* code = strstr(buff, " ");
    code++;
    httpCode = atoi(code);
}

void HttpResponse::skipInnerJsonObject() {
    int depth=1;
    char c;
    while(depth>0) {
        c = gsm.read();
        if(c=='{')
            depth++;
        else if(c=='}')
            depth--;
    }
}

bool HttpResponse::locateJsonValue(const char* jsonPath) {
    int i=0; // character index that matched
    int pieceBeginning=0;
    char c;
    while(i < strlen(jsonPath)) {
        c = gsm.read();
        if (c > 0) {
            if (c == jsonPath[i]) {
                if (jsonPath[++i] == '/') {
                    i++;
                    pieceBeginning = i;

                    // read to open inner object
                    while (c != '{')
                        c = gsm.read();
                }
            } else {
                // not matching any letter
                i=pieceBeginning;
                if (i != 0) {
                    // at least one outer object already found
                    // but inner object char not yet matching
                    if (c == '{') { // entering inner object, we want to skip it entirely...
                        skipInnerJsonObject();
                    }
                }
            }
        }
    }
    return i==strlen(jsonPath);
}

void HttpResponse::findFirstLetter() {
    char c;
    while(true) {
        c = gsm.read();
        if(c>0 && isAlpha(c)) {
            bufferForValue[0] = c;
            break; // found first letter
        }
    }
}

void HttpResponse::readStringValue(int maxExpectedLength) {

    // read to buffer until " char
    int i = 1;
    char c;
    while(i<maxExpectedLength-1) {
        c = gsm.read();
        if(c>0 && c!='\\') { // TODO handle double backlash also (ignore once)
            if(c=='"')
                break;
            bufferForValue[i++] = c;
        }
    }
    bufferForValue[i++] = '\0';
    if(i==maxExpectedLength) {
        // TODO out of bounds! raise an error!
    }
}

HttpResponse::HttpResponse(GSMModule* mod, const char* jsonPath, int maxExpectedLength) {

    readHttpCode();

    if(locateJsonValue(jsonPath)) {
        // json path found, now get value
        bufferForValue = (char*) malloc(maxExpectedLength);

        findFirstLetter();
        readStringValue(maxExpectedLength);

    } else {
        // TODO value not found in json, raise an error!
    }

    mod->getInet().disconnectTCP(); //fails...
}
int HttpResponse::getHttpCode() {
    return httpCode;
}
/* we want the stored value to stay after destruction of response... we will remove it manually.
HttpResponse::~HttpResponse() {
    clean();
}*/
void HttpResponse::cleanMemory() {
    free(bufferForValue);
}

HttpRequest::HttpRequest(GSMModule* mod,char* host, char* path, int port, const char* type) : mod(mod) {
    boolean connected=false;
    int n_of_at=0;
    while(n_of_at<3) {
        if(!mod->getInet().connectTCP(host, port)) {
#ifdef DEBUG_ON
            Serial.println("DB:NOT CONN");
#endif
            n_of_at++;
        } else {
            connected=true;
            n_of_at=3;
        }
    }
    if(!connected)
        Serial.println("TCP Failed");

    gsm.SimpleWrite(type);
    gsm.SimpleWrite(" ");
    gsm.SimpleWrite(path);
    gsm.SimpleWrite(" HTTP/1.1\n");
    gsm.SimpleWrite("Host: ");
    gsm.SimpleWrite(host);
}

void HttpRequest::authorization(const char* authorization) {
    gsm.SimpleWrite("\nAuthorization: Basic ");
    gsm.SimpleWrite(authorization);
}
void HttpRequest::applicationKey(const char* applicationKey) {
    gsm.SimpleWrite("\nX-Cumulocity-Application-Key: ");
    gsm.SimpleWrite(applicationKey);
}
void HttpRequest::contentType(const char* contentType) {
    gsm.SimpleWrite("\nContent-Type: ");
    gsm.SimpleWrite(contentType);
}
void HttpRequest::accept(const char* contentType) {
    gsm.SimpleWrite("\nAccept: ");
    gsm.SimpleWrite(contentType);
}
HttpResponse HttpRequest::execute(char* content, const char* jsonPath, int maxExpectedLength) {
    gsm.SimpleWrite("\n\n");
    gsm.SimpleWrite(content);
    execute(jsonPath, maxExpectedLength);
}

HttpResponse HttpRequest::execute(const char* jsonPath, int maxExpectedLength) {
    gsm.SimpleWrite("\n\n");
    char end_c[2];
    end_c[0]=0x1a;
    end_c[1]='\0';
    gsm.SimpleWrite(end_c);

    switch(gsm.WaitResp(10000, 100, "SEND OK")) {
    case RX_TMOUT_ERR:
        Serial.println("RX TMOUT ERR");
        break;
    case RX_FINISHED_STR_NOT_RECV:
        Serial.println("RX FINISHED STR");
        break;
    }
    Serial.println("\nREQ SENT");

    return HttpResponse(mod, jsonPath, maxExpectedLength);
}

HttpClient::HttpClient(GSMModule* mod) : mod(mod)
{}

HttpRequest HttpClient::createRequest(char* url, const char* type) {
    char* path = strstr(url, "/");
    char host[path-url+1];
    strncpy(host, url, path-url);
    host[path-url] = '\0';

    char* port_str = strstr(url, ":");
    int port = 80;
    if(port_str)
        port = atoi(++port_str);

    return HttpRequest(mod, host, path, port, type);
}

HttpRequest HttpClient::get(char* url) {
    return createRequest(url, "GET");
}

HttpRequest HttpClient::post(char* url) {
    return createRequest(url, "POST");
}

// ------------------ Constructors, destructor

void CumulocityPlatform::Construct(char* _host, int _port, char* _tenantId, char* _user, char* _password, char* _applicationKey)
{
    host = _host;
    port = _port;
    tenantId = _tenantId;
    user = _user;
    password = _password;
    applicationKey = _applicationKey;
}

CumulocityPlatform::CumulocityPlatform(char* host, int port, char* tenantId, char* user, char* password, char* applicationKey)
{
    Construct(host, port, tenantId, user, password, applicationKey);
}
CumulocityPlatform::CumulocityPlatform(char* host, char* tenantId, char* user, char* password, char* applicationKey)
{
    Construct(host, 80, tenantId, user, password, applicationKey);
}


CumulocityPlatform::~CumulocityPlatform() {}

// ------------------ private

void CumulocityPlatform::writeAuth(HttpRequest& request) {
    //<realm>/<user name>:<password>
    int input_size = strlen(tenantId) + strlen(user) + strlen(password) + 2;
    int output_size = ((input_size * 4) / 3) + (input_size / 96) + 6;
    char plain_auth[input_size];
    char encoded_auth[output_size];

    strcpy(plain_auth,tenantId);
    strcat(plain_auth,"/");
    strcat(plain_auth,user);
    strcat(plain_auth,":");
    strcat(plain_auth,password);

    base64_encode(encoded_auth, plain_auth, input_size);

    request.authorization(encoded_auth);
}

char* CumulocityPlatform::getInventoryUrl() {

    // Connect to Cumulocity server

    HttpClient client(mod);

    char url[strlen(host) + 10];
    strcpy(url, host);
    strcat(url, "/platform");

    HttpRequest request = client.get(url);
    writeAuth(request);
    request.applicationKey(applicationKey);

    HttpResponse response = request.execute("managedObjects/self", 60);

    return response.getRequestedValue();
}

void CumulocityPlatform::saveIdInEEPROM(char* id) {

}

char* CumulocityPlatform::readIdFromEEPROM() {
    int i=0;
    char c;
    do {
        c = (char) eeprom_read_byte((unsigned char* )i++);
        if(c == -1)
            return NULL;
    } while(c != -1 && c != 0);

    if(i == 0)
        return NULL;

    char* buff = (char*) malloc( (i+1) * sizeof( char ) );
    for(int k=0; k<=i; k++) {
        buff[k] = (char) eeprom_read_byte((unsigned char* )i++);
    }

    return buff;
}

int CumulocityPlatform::registerInCumulocity(const char* type, const char* name, char* id) {

    char* url = getInventoryUrl();
    /*
     * {"name":"XXX",
     *  "type":"YYY"}
     */

    char content[22 + strlen(name) + strlen(type)];
    strcpy(content, "{\"name\":\"");
    strcat(content, name);
    strcat(content, "\",\"type\":\"");
    strcat(content, type);
    strcat(content, "\"}");

    Serial.println(url);
    Serial.println(content);


    HttpClient client(mod);
    HttpRequest request = client.post(url);
    free(url);
    writeAuth(request);
    request.applicationKey(applicationKey);
    request.contentType(CUMULOCITY_CT_MANAGED_OBJECT_09);
    request.accept(CUMULOCITY_CT_MANAGED_OBJECT_09);

    HttpResponse response = request.execute(content, "id", 60);
    Serial.println(response.getRequestedValue());

    if(response.getHttpCode() == 201) { // created
        return 1;
    }
    else {
        return -1;
    }
}


bool CumulocityPlatform::deviceRegistered(const char* id,const char* type,const char* name) {
    return false;
}

// ------------------ public API

int CumulocityPlatform::registerDevice(char* name, char* id) {
    char* savedId = readIdFromEEPROM();
    if(savedId != NULL) {
        // no ID saved
        if(deviceRegistered(savedId, CUMULOCITY_ARDUINO_TYPE, name)) {
            id = strcpy(id, savedId);
            free(savedId);
            return 0; // already registered,
        }
    }

    // either not in EEPROM, or not in Cumulocity
    int exitcode = registerInCumulocity(CUMULOCITY_ARDUINO_TYPE, name, id);
    saveIdInEEPROM(id);
    return exitcode;
}

char* CumulocityPlatform::getPendingOperationFromServer(const char* operationFragmentName) {
    return NULL;
}

int CumulocityPlatform::raiseAlarm(int sourceId, int type, int status, int severity, char* text) {
    return 0;
}

int CumulocityPlatform::raiseAlarm(int sourceId, int type, int status, int severity, char* time, char* text) {
    return 0;
}

int CumulocityPlatform::sendMeasurement(int sourceId, int type, Measurement measurement) {
    return 0;
}

int CumulocityPlatform::sendMeasurement(int sourceId, int type, char* time, Measurement measurement) {
    Serial.print("Sending measurement: ");
    Serial.print(measurement.value);
    Serial.print(measurement.unit);
    Serial.println(".");
    return 0;
}

char* CumulocityPlatform::getTime() {
    return NULL;
}

void CumulocityPlatform::triggerHandlersIfCommandsAwaiting() {}
void CumulocityPlatform::registerForServerOperation(void (*functionPtr)(char*), char* operationFragmentName, int interval) {}
int CumulocityPlatform::updateOperationStatus(char* operationId, int newStatus) {
    return -1;
}

// ------------------ GSMModule-related methods

void CumulocityPlatform::setGSM(GSMModule* mod) {
    this->mod = mod;
}

GSMModule::GSMModule() {}
GSMModule::~GSMModule() {}

int GSMModule::attachGPRS(char* domain, char* dom1, char* dom2) {
    int ret = gsm.begin(2400);
    if(ret) {
        gsm.forceON();
        return inet.attachGPRS(domain, dom1, dom2);
    }
    return ret;
}

int GSMModule::dettachGPRS() {
    return inet.dettachGPRS();
}

void GSMModule::initClock(char* time) {

}

InetGSM GSMModule::getInet() {
    return inet;
}

void base64_encode(char* output, char const* input, unsigned int in_len) {
    int i = 0;
    int j = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];
    int out_idx = 0;

    while (in_len--) {
        char_array_3[i++] = *(input++);
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;

            for(i = 0; (i <4) ; i++)
                output[out_idx++] = base64_chars[char_array_4[i]];
            i = 0;
        }
    }

    if (i) {
        for(j = i; j < 3; j++)
            char_array_3[j] = '\0';

        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
        char_array_4[3] = char_array_3[2] & 0x3f;

        for (j = 0; (j < i + 1); j++)
            output[out_idx++] = base64_chars[char_array_4[j]];

        while((i++ < 3))
            output[out_idx++] = '=';
    }
    output[out_idx++] = '\0';
}
