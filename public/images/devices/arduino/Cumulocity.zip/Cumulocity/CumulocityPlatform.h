/*
 * CumulocityPlatform.h
 *
 *  Created on: Jan 2, 2013
 *      Author: ostache
 */

#ifndef CUMULOCITYPLATFORM_H
#define CUMULOCITYPLATFORM_H

#define CUMULOCITY_LIB_VERSION 001 // library version X.YY (e.g. 1.00)

#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include "inetGSM.h"

const int CUMULOCITY_ALARM_TYPE_1 = 1;
const int CUMULOCITY_ALARM_TYPE_2 = 2;

const int CUMULOCITY_MEASUREMENT_TYPE_1 = 1;
const int CUMULOCITY_MEASUREMENT_TYPE_2 = 2;

const int CUMULOCITY_SEVERITY_CRITICAL = 1;
const int CUMULOCITY_SEVERITY_MAJOR = 2;
const int CUMULOCITY_SEVERITY_MINOR = 3;
const int CUMULOCITY_SEVERITY_WARNING = 4;

const int CUMULOCITY_ALARM_STATUS_ACTIVE = 1;
const int CUMULOCITY_ALARM_STATUS_ACKNOWLEDGED = 2;
const int CUMULOCITY_ALARM_STATUS_CLEARED = 3;

struct Measurement {
    long value;
    char* unit;
};

class GSMModule {

    // TODO keep state of connection
    // attach/detach -> connect/disconnect

protected:
    InetGSM inet;
public:

    virtual ~GSMModule();
    GSMModule();

    int attachGPRS(char*, char*, char*);
    int dettachGPRS();
    void initClock(char* time);

    InetGSM getInet();
};

class HttpResponse {
private:
    int httpCode;
    char* bufferForValue;

    void readHttpCode();
    void skipInnerJsonObject();
    void readStringValue(int maxExpectedLength);
    void findFirstLetter();
    bool locateJsonValue(const char* jsonPath);
public:
    HttpResponse(GSMModule* mod, const char* jsonPath, int maxExpectedLength);
//    virtual ~HttpResponse();
    int getHttpCode();
    char* getRequestedValue();
    void cleanMemory();
};

class HttpRequest {
private:
    GSMModule* mod;
public:
    HttpRequest(GSMModule* mod, char* host, char* path, int port, const char* type);

    void authorization(const char* authorization);
    void applicationKey(const char* applicationKey);
    void contentType(const char* contentType);
    void accept(const char* contentType);

    HttpResponse execute(char* content, const char* jsonPath, int maxExpectedLength);
    HttpResponse execute(const char* jsonPath, int maxExpectedLength);
};

class HttpClient {
protected:
    GSMModule* mod;
    HttpRequest createRequest(char* url, const char* type);
public:
    HttpClient(GSMModule* mod);
    HttpRequest get(char* url);
    HttpRequest post(char* url);
};

class CumulocityPlatform {

private:
    const char* host;
    char* tenantId;
    char* user;
    char* password;
    const char* applicationKey;
    int port;

    GSMModule* mod;

    char* getInventoryUrl();
    char* getPlatformUrl();
    char* getMeasurementsUrl();
    char* getAlarmsUrl();
    char* getDeviceControlUrl();

    void writeAuth(HttpRequest& request);

    char* readIdFromEEPROM();
    void saveIdInEEPROM(char* id);
    bool deviceRegistered(const char* ,const char*,const char*);
    int registerInCumulocity(const char*,const char*, char* id);
    void Construct(char* _host, int _port, char* _tenantId, char* _user, char* _password, char* _applicationKey);

public:
    // TODO add const to arguments where needed


    virtual ~CumulocityPlatform();

    CumulocityPlatform(char* host, char* tenantId, char* user, char* password, char* applicationKey);
    CumulocityPlatform(char* host, int port, char* tenantId, char* user, char* password, char* applicationKey);

    int raiseAlarm(int sourceId, int type, int status, int severity, char* time, char* text);
    int raiseAlarm(int sourceId, int type, int status, int severity, char* text);

    //do we need struct for measurement
    int sendMeasurement(int sourceId, int type, char* time, Measurement measurement);
    int sendMeasurement(int sourceId, int type, Measurement measurement);

    // Required for both solutions
    int registerDevice(char* name, char* returnId);

    char* getPendingOperationFromServer(const char* operationFragmentName);
    int updateOperationStatus(char* operationId, int newStatus); // status - const

    // Required for second solution
    void triggerHandlersIfCommandsAwaiting();
    void registerForServerOperation(void (*handler)(char*), char* operationFragmentName, int interval);

    void setGSM(GSMModule*);
    char* getTime();
};

/* -------------------- BASE64 -------------------- */

static const char* base64_chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789+/";
void base64_encode(char* output, char const* input, unsigned int in_len);

#endif /* CUMULOCITYPLATFORM_H_ */
