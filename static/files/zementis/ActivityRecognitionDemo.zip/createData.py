'''
Created April 15, 2019 for activities demo
@author: blit

Create a CSV data set for a particular time range and activity
'''

import configparser
import csv, os
import requests
import queue
import numpy as np


def add2Data(d, writer, activity):

	acc = d['c8y_Acceleration']	
	accelerationX = acc['accelerationX']
	accX_Val=accelerationX['value']
	accelerationY = acc['accelerationY']
	accY_Val=accelerationY['value']
	accelerationZ = acc['accelerationZ']
	accZ_Val=accelerationZ['value']

	
	# cutting off the first instances of the training data as the std dev is not accurate for those			
	writer.writerow([accX_Val, accY_Val, accZ_Val, activity])


# collect config from CONFIG-INI -> change user and pass
config = configparser.ConfigParser()
config.read('CONFIG.INI')

# use the dates in which a particular acitvity was perfomed
DATE_FROM="2019-05-16T13:15:36.000-07:00"
DATE_TO="2019-05-16T13:15:59.000-07:00"

# specify the recorded activity
ACTIVITY="jump"

c_measurements_endpoint="/measurement/measurements/"

# maximum page size is 2000; only taking acceleration measurements
c_params={"source":config.get("cumulocity", "c_device_source"),"pageSize":"2000", "dateFrom":DATE_FROM, "dateTo":DATE_TO, "fragmentType":"c8y_Acceleration"}


# get first page of json data measurements from cumulocity
c_auth=config.get("cumulocity", "c_user"),config.get("cumulocity", "c_pass")
r=requests.get(config.get("cumulocity","c_url")+c_measurements_endpoint,params=c_params, auth=c_auth) 
print("Start collecting data from: "+r.url)
print("Status code: "+str(r.status_code))

# training data file
DIR_DATA="data/"
DATA_FILE=DIR_DATA+"generated_dataset_"+ACTIVITY+".csv"

 # collect data
json_doc=r.json()
data=[]

if not os.path.exists(DIR_DATA):
    os.makedirs(DIR_DATA)
    
with open(DATA_FILE, mode='w') as training_file:
	writer = csv.writer(training_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
	writer.writerow(["accelerationX","accelerationY","accelerationZ", "activity"])
	
	first_arr=json_doc['measurements']	
	
	print("Page 1.\tCollecting data at: " +first_arr[0]['time'])
	
	for d in first_arr:	
		add2Data(d, writer, ACTIVITY)
		 

	# change the range depending on amount of training data required
	for i in range(5):
		r=requests.get(json_doc['next'], auth=c_auth) 
		next_doc=r.json()
		measure_arr=next_doc['measurements']
	
		if not measure_arr:
			print("Last page reached.")
			break
	
		print("Page "+ str(i+2)+".\tCollecting data at: "+ measure_arr[0]['time'])

		for d in measure_arr:	
			add2Data(d, writer, ACTIVITY)
			
		json_doc=next_doc

print("Data written to " + DATA_FILE)  

