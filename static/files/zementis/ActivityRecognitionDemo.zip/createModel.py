from sklearn import tree
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from nyoka import skl_to_pmml
from nyoka.preprocessing import Lag
import graphviz
import numpy as np
import os
import pandas as pd
import warnings

warnings.filterwarnings('ignore')

DIR="data/"
FILE_NAME="demo_data_jump"
CSV=".csv"
TRAINING_FILE_NAME=DIR+"training_"+FILE_NAME+CSV
TEST_FILE_NAME=DIR+"test_"+FILE_NAME+CSV
PMML_FILE_NAME="pmml/generated_"+FILE_NAME+".pmml"

features=['accelerationX', 'accelerationY', 'accelerationZ']
category='activity'

df_train = pd.read_csv(TRAINING_FILE_NAME, header = 0)

X=df_train[features]
y=df_train[category]

df_test = pd.read_csv(TEST_FILE_NAME, header = 0)
X_test=df_test[features]
y_test=df_test[category]

lag = Lag(aggregation="stddev", value=5)

# instantiate the decision model object, here we are using a decision tree,
model_type="d_tree"
model=tree.DecisionTreeClassifier(class_weight=None, criterion='entropy', max_depth=3,
            max_features=None, max_leaf_nodes=None,
            min_impurity_decrease=0.0, min_impurity_split=None,
            min_samples_leaf=9, min_samples_split=2,
            min_weight_fraction_leaf=0.0, presort=True, random_state=None,
            splitter='best')
             
# train the model
transformed_X = lag.fit_transform(X)
model.fit(transformed_X,y)
print("Model trained: ", model)
 
# the following code can be used to show all classifications for the test data
# output_classes=model.predict(X_test)
# print("Computed results: ",output_classes)
 
# compute the cross validation score
scores = cross_val_score(model, transformed_X, y, cv=10)
print("Accuracy with 10-fold cross validation:\t %0.2f (+/- %0.2f)%%" % (scores.mean(), scores.std() * 2))
 
# test the model against data that was generated from another user
transformed_X_test = lag.fit_transform(X_test)
result=model.score(transformed_X_test, y_test)
print("Accuracy against test data:\t\t {:.4%}".format(result))
 
# convert model into PMML
print("Start converting the model into PMML...")

lag_obj = Lag(aggregation="stddev", value=5)

pipeline = Pipeline([
	('lag', lag_obj),
    (model_type, model)
])
pipeline.fit(X,y)
skl_to_pmml(pipeline, features, "activity", PMML_FILE_NAME)
print("Model with name "+PMML_FILE_NAME+" converted into PMML")
 
#create graph for visualization of the model; this will only work for decision trees
dot_data = tree.export_graphviz(model, out_file=None, feature_names=features,
                     class_names=model.classes_,
                     filled=True, rounded=True, 
                     special_characters=True) 
graph = graphviz.Source(dot_data)
graph.render("graph_"+model_type)
print("Graph with decision tree is created as graph_" + model_type + ".pdf.")