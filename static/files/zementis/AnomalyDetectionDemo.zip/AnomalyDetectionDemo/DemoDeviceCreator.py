# Register a demo device with Cumulocity IoT

import requests
import json
from requests.auth import HTTPBasicAuth
import datetime

data = json.load(open('../Data/CONFIG.json',))

payload={'name': 'DemoDevice',
 'c8y_IsDevice': [],
 'c8y_SupportedMeasurements': ['RoboSensors'],
 'c8y_SupportedOperations': ['c8y_Restart',
  'c8y_Configuration',
  'c8y_Software',
  'c8y_Firmware',
  'c8y_Command']}

url = data['c_url']+"/inventory/managedObjects"
headers = {
    'Content-Type': "application/json",
    'Accept': "application/json",
    'cache-control': "no-cache",
    'Postman-Token': "2dc79351-5a48-4b8b-b4f2-30b880732d01"
    }

response = requests.request("POST", url, data=json.dumps(payload), headers=headers,auth=HTTPBasicAuth(data['c_user'], data['c_pass']))

print("The device id is:" , json.loads(response.text)['id'])

