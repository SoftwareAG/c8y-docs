# Simulate anamolous and non-anamolous data
import requests
import json
from requests.auth import HTTPBasicAuth
import datetime
import random
data = json.load(open('../Data/CONFIG.json',))

url = data['c_url']+"/measurement/measurements"

# Simulated anamolous data
tt=datetime.datetime.now()

headers = {
'Content-Type': "application/json",
'Accept': "application/vnd.com.nsn.cumulocity.measurement+json",
'cache-control': "no-cache",
'Postman-Token': "2d5fa27d-c8c8-428c-b2f9-0efe9490b716"
}

payload1={'type': 'anamoly',
    'time': str(tt.date())+'T'+str(tt.hour)+':'+str(tt.minute)+':'+str(tt.second)+'+05:30',
    'source': {'id': data['c_device_source']},
    "c8y_Acceleration":{"accelerationY":{"unit":"G","value":-0.2631993591785431},
                        "accelerationX":{"unit":"G","value":5.769125938415527},
                    "accelerationZ":{"unit":"G","value":8.193016052246094}},
    "c8y_Gyroscope":{"gyroX":{"unit":"°/s","value":-0.03604104742407799},
                    "gyroY":{"unit":"°/s","value": 0.055571284145116806},
                    "gyroZ":{"unit":"°/s","value":-0.0010122909443452952}}
}

response = requests.request("POST", url, data=json.dumps(payload1), 
                        headers=headers,auth=HTTPBasicAuth(data['c_user'], data['c_pass']))

# Simulated non-anamolous data
tt=datetime.datetime.now()
payload2={'type': 'non-anamoly',
    'time': str(tt.date())+'T'+str(tt.hour)+':'+str(tt.minute)+':'+str(tt.second)+'+05:30',
    'source': {'id': data['c_device_source']},
    "c8y_Acceleration":{"accelerationY":{"unit":"G","value":0.0971527099609375},
                        "accelerationX":{"unit":"G","value":0.6249847412109375},
                    "accelerationZ":{"unit":"G","value":-0.2371368408203125}},
    "c8y_Gyroscope":{"gyroX":{"unit":"°/s","value":-1.2540942430496216},
                    "gyroY":{"unit":"°/s","value": -1.861748218536377},
                    "gyroZ":{"unit":"°/s","value":-0.029031118378043175}}
}

response = requests.request("POST", url, data=json.dumps(payload2), 
                        headers=headers,auth=HTTPBasicAuth(data['c_user'], data['c_pass']))

