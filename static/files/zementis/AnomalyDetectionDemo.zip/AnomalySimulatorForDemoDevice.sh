c_url=$(awk -F "=" '/c_url/ {print $2}' ./CONFIG.INI)
c_user=$(awk -F "=" '/c_user/ {print $2}' ./CONFIG.INI)
c_pass=$(awk -F "=" '/c_pass/ {print $2}' ./CONFIG.INI)
c_device_source=$(awk -F "=" '/c_device_source/ {print $2}' ./CONFIG.INI)
end=$((SECONDS+30))
COUNTER=0
DIV=2
CURRENT_TIME=$(date --iso-8601=seconds)
while [ $SECONDS -lt $end ]; do
    result=`expr $COUNTER % $DIV`
	if [ $result == 0 ]
	then
		echo
		echo "##########################################"
		echo "#  Simulating Non-Anamolous Measurement  #"
		echo "##########################################"
		echo
		curl --user $c_user:$c_pass -X POST $c_url"/measurement/measurements" -H "accept: application/vnd.com.nsn.cumulocity.measurementCollection+json" -H "Content-Type: application/json" \
		--data '{"measurements":[{"time":"'$CURRENT_TIME'","source":{"id":"'$c_device_source'"},"type":"c8ydemoAndroid","c8y_Acceleration":{"accelerationY":{"unit":"G","value": -0.2631993591785431},"accelerationX":{"unit":"G","value":5.769125938415527},"accelerationZ":{"unit":"G","value":8.193016052246094}},"c8y_Gyroscope":{"gyroX":{"unit":"�/s","value":-0.03604104742407799},"gyroY":{"unit":"�/s","value": 0.055571284145116806},"gyroZ":{"unit":"�/s","value":,-0.0010122909443452952}}}]}'
		sleep 2
	fi
	if [ $result -eq 1 ]
	then
		echo
		echo "##########################################"
		echo "#    Simulating Anamolous Measurement    #"
		echo "##########################################"
		echo
		curl --user $c_user:$c_pass -X POST $c_url"/measurement/measurements" -H "accept: application/vnd.com.nsn.cumulocity.measurementCollection+json" -H "Content-Type: application/json" \
		--data '{"measurements":[{"time":"'$CURRENT_TIME'","source":{"id":"'$c_device_source'"},"type":"c8ydemoAndroid","c8y_Acceleration":{"accelerationY":{"unit":"G","value":-27.943368911743164},"accelerationX":{"unit":"G","value":-26.63686370849609},"accelerationZ":{"unit":"G","value":7.422532558441162}},"c8y_Gyroscope":{"gyroX":{"unit":"�/s","value":-13.211706161499025},"gyroY":{"unit":"�/s","value":7.483762264251709},"gyroZ":{"unit":"�/s","value":-11.959641456604006}}}]}'
		sleep 2
	fi
	COUNTER=`expr $COUNTER + 1`
done