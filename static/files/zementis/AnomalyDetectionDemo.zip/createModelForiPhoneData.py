from sklearn.ensemble import IsolationForest
from sklearn.pipeline import Pipeline
import numpy as np
import os
import zipfile
import csv
from nyoka import skl_to_pmml
import warnings
warnings.filterwarnings('ignore')

# training data file
DIR_DATA="data/"
TRAIN_DATA_FILE=DIR_DATA+"dataset_training_iphone.csv"

DIR_MODEL="model/"
PMML_FILE_NAME = DIR_MODEL+"iforest_model_iphone.pmml"

if not os.path.exists(DIR_MODEL):
    os.makedirs(DIR_MODEL)

# load the data into an array
with open(TRAIN_DATA_FILE, newline='') as csvfile:
    data = list(csv.reader(csvfile))

# instantiate the isolation forest object
iforest = IsolationForest(n_estimators=40, max_samples=3000, contamination=0, random_state=np.random.RandomState(42))
# only use part of the data for quicker results
iforest.fit(data[1:])

# prepare pipeline for PMML conversion
model_type="iforest"
print("Start converting the model into PMML...")
pipeline = Pipeline([
    (model_type, iforest)
])

pipeline.fit(data[1:])
features = ["accelerationY","accelerationX","accelerationZ","gyroX","gyroY","gyroZ"]
skl_to_pmml(pipeline, features, "",PMML_FILE_NAME)

print("Model with name "+PMML_FILE_NAME+" converted into PMML")