'''
Created on Apr 10, 2019

@author: blit

Script to get json measurements from cumulocity and to load to CSV
'''

import requests, json 
import configparser
import csv
import os

def add2Data(d):
# consult returned JSON for exact format
	c8y_SignalStrengthWifi = d['c8y_SignalStrengthWifi']
	rssi = c8y_SignalStrengthWifi['rssi']
	acc = d['c8y_Acceleration']
	accelerationY = acc['accelerationY']
	accelerationX = acc['accelerationX']
	accelerationZ = acc['accelerationZ']
	c8y_Barometer = d['c8y_Barometer']
	air_pressure = c8y_Barometer['Air pressure']
	c8y_Gyroscope = d['c8y_Gyroscope']
	gyroX = c8y_Gyroscope['gyroX']
	gyroY = c8y_Gyroscope['gyroY']
	gyroZ = c8y_Gyroscope['gyroZ']
	c8y_Luxometer = d['c8y_Luxometer']
	lux = c8y_Luxometer['lux']
	c8y_Compass = d['c8y_Compass']
	compassX = c8y_Compass['compassX']
	compassY = c8y_Compass['compassY']
	compassZ = c8y_Compass['compassZ']
	return [rssi['value'], accelerationY['value'], accelerationX['value'], accelerationZ['value'], air_pressure['value'], gyroX['value'], gyroY['value'], gyroZ['value'], lux['value'], compassX['value'], compassY['value'], compassZ['value']]
	

# collect config from CONFIG-INI -> change user and pass
config = configparser.ConfigParser()
config.read('CONFIG.INI')

c_measurements_endpoint="/measurement/measurements/"
c_params={"source":config.get("cumulocity", "c_device_source"),"pageSize":"2000"}


# get first page of json data measurements from cumulocity
c_auth=config.get("cumulocity", "c_user"),config.get("cumulocity", "c_pass")
r=requests.get(config.get("cumulocity","c_url")+c_measurements_endpoint,params=c_params, auth=c_auth) 
print("Start collecting data from: "+r.url)
print("Status code: "+str(r.status_code))

# training data file
DIR_DATA="data/"
TRAIN_DATA_FILE=DIR_DATA+"dataset_training.csv"

 # collect data
json_doc=r.json()
data=[]

if not os.path.exists(DIR_DATA):
    os.makedirs(DIR_DATA)
    
with open(TRAIN_DATA_FILE, mode='w') as training_file:
	writer = csv.writer(training_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
	writer.writerow(["rssi","accelerationY","accelerationX","accelerationZ","air_pressure","gyroX","gyroY","gyroZ","lux","compassX","compassY","compassZ"])


	# write measurements of first page
	for measurement in json_doc['measurements']:	
		writer.writerow(add2Data(measurement))		 

	for i in range(5):
		r=requests.get(json_doc['next'], auth=c_auth) 
		next_doc=r.json()
		measure_arr=next_doc['measurements']
	
		if not measure_arr:
			print("Last page reached.")
			break
	
		print("Collecting data at: " +measure_arr[0]['time'])

		for measurement in measure_arr:	
			writer.writerow(add2Data(measurement))
			
		json_doc=next_doc

print("Training data written to " + TRAIN_DATA_FILE)



