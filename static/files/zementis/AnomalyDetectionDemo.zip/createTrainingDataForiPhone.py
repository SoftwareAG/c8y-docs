import requests, json 
import configparser
import csv
import os

def add2Data(acc_data, gyro_data, writer):
    acc_X = acc_data['accelerationX']['value']
    acc_Y = acc_data['accelerationY']['value']
    acc_Z = acc_data['accelerationZ']['value']
    gyro_X = gyro_data['gyroX']['value']
    gyro_Y = gyro_data['gyroY']['value']
    gyro_Z = gyro_data['gyroZ']['value']
    writer.writerow([acc_X,acc_Y,acc_Z,gyro_X,gyro_Y,gyro_Z])

config = configparser.ConfigParser()
config.read('CONFIG.INI')

DATE_FROM="2019-09-06T23:00:00.000+05:30"
DATE_TO="2019-09-07T08:00:00.000+05:30"

c_measurements_endpoint="/measurement/measurements/"
c_params={"source":config.get("cumulocity", "c_device_source"),"pageSize":"2000",
         "dateFrom":DATE_FROM, "dateTo":DATE_TO,
         "fragmentType":"c8y_Acceleration"}

c_auth=config.get("cumulocity", "c_user"),config.get("cumulocity", "c_pass")
r=requests.get(config.get("cumulocity","c_url")+c_measurements_endpoint,params=c_params, auth=c_auth)
print("Start collecting data from: "+r.url)
print("Status code: "+str(r.status_code))

DIR_DATA="data/"
TRAIN_DATA_FILE=DIR_DATA+"dataset_training_iphone.csv"

json_doc_acc=r.json()

if not os.path.exists(DIR_DATA):
    os.makedirs(DIR_DATA)

with open(TRAIN_DATA_FILE, mode='w', newline='') as training_file:
    writer = csv.writer(training_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    writer.writerow(["accelerationX","accelerationY","accelerationZ","gyroX","gyroY","gyroZ"])
    first_arr=json_doc_acc['measurements']

    c_params.update({'fragmentType':'c8y_Gyroscope'})
    r=requests.get(config.get("cumulocity","c_url")+c_measurements_endpoint,params=c_params, auth=c_auth)
    json_doc_gyro = r.json()

    print("Page 1.\tCollecting data at: " +first_arr[0]['time'])

    for data in first_arr:
        gyro = list(filter(lambda rec: rec['time']==data['time'], json_doc_gyro['measurements']))
        # For some timestamps, acceleration measurements are there but not gyroscope; skipping records with those timestamps
        if len(gyro)>0:
            add2Data(data['c8y_Acceleration'], gyro[0]['c8y_Gyroscope'], writer)

    for i in range(5):
        r=requests.get(json_doc_acc['next'], auth=c_auth) 
        next_doc_acc=r.json()
        measure_arr=next_doc_acc['measurements']
        if not measure_arr:
            print("Last page reached.")
            break

        r=requests.get(json_doc_gyro['next'], auth=c_auth) 
        next_doc_gyro=r.json()
        if not next_doc_gyro['measurements']:
            print("Last page reached.")
            break

        print("Page "+ str(i+2)+".\tCollecting data at: "+ measure_arr[0]['time'])

        for data in measure_arr:
            gyro = list(filter(lambda rec: rec['time']==data['time'], next_doc_gyro['measurements']))
            # For some timestamps, acceleration measurements are there but not gyroscope; skipping records with those timestamps
            if len(gyro)>0:
                add2Data(data['c8y_Acceleration'], gyro[0]['c8y_Gyroscope'], writer)
        json_doc_acc = next_doc_acc
        json_doc_gyro = next_doc_gyro

print("Training data written to " + TRAIN_DATA_FILE)
