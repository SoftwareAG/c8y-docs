import numpy as np
from PIL import Image
import io
def process(content):
    im = Image.open(io.BytesIO(content)).convert('RGB')
    im = im.resize((250,250))
    x = np.array(im,dtype=np.float32)
    x = np.expand_dims(x,0)
    return {"Conv2D_input":x}
