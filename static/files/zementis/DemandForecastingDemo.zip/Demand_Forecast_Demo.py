import requests
from requests.auth import HTTPDigestAuth
import json
from jsonpath_ng import jsonpath, parse
import time
import pandas as pd
from pandas import read_csv
import csv
from datetime import datetime as pdt,timedelta, date
import os
import matplotlib as inline
import datetime
import configparser
import sys
import shutil


config = configparser.ConfigParser()
config.read('CONFIG.ini')
tenant_url =config['cumulocity']['c_url']
user_name=config['cumulocity']['c_user']
password=config['cumulocity']['c_pass']
tz_zone_info='0530'

deviceID=config['cumulocity']['c_device_source']
measurement='c8y_InflowPressure'

#start Date
stDate="2019-12-01"
#duration
duration=7 
training_start_date=''

stDate=stDate+"T00:00:00+"+tz_zone_info

START_DATE= datetime.datetime.strptime(stDate, "%Y-%m-%dT%H:%M:%S%z").date()
END_DATE=START_DATE+timedelta(days=int(duration))

endDate=datetime.datetime.strftime(END_DATE,"%Y-%m-%d")

c8y_Flow=list()
measurement_times=list()

if not os.path.exists('temp'):
    os.mkdir("temp")

def get_exception_msg(resp_text):
    resp_json=json.loads(resp_text)
    if 'error' in resp_json:
        return resp_json['error']
    elif 'errors' in resp_json:
        return resp_json['errors']

def get_measurement_request(newurl):
    response=requests.get(url = newurl, auth=(user_name, password), verify=True)
    return response;
    

def extract_measurements(responseContent):
    jData = json.loads(responseContent)
    jsonpath_expression = parse('$.measurements[*].c8y_Flow.F.value')
    for match in jsonpath_expression.find(jData):
        c8y_Flow.append(float(f'{match.value}'))
        
    jsonpath_expression = parse('$.measurements[*].time')
    for match in jsonpath_expression.find(jData):
        measurement_times.append(f'{match.value}')
    training_start_date_expr = parse('$.measurements[0].time')
    for match1 in training_start_date_expr.find(jData):
        global training_start_date
        training_start_date = str(f'{match1.value}')

def prepare_time_series_data_for_training():
    global training_start_date
    data={}
    datetimes = []
    for x in measurement_times:
        tmp_time=pdt.strptime(x.split('+')[0], "%Y-%m-%dT%H:%M:%S.%f")
        datetimes.append(pd.Timestamp(tmp_time))
    df=pd.DataFrame(data=c8y_Flow,index=pd.DatetimeIndex(datetimes))
    df.to_csv('temp/input_data_for_training.csv')
    data['startDate']=training_start_date #str(START_DATE)+'T00:00:00+05:30'
    startDate = pdt.strptime(str(START_DATE)+'T00:00:00', "%Y-%m-%dT%H:%M:%S")
    datetimes = []
    last_date_time = startDate
    data['series'] = df.values.flatten().tolist()
    interval={}
    interval['timeUnit']='HOURS'
    interval['periodLength']=2
    data['observationInterval']=interval
    seasonality={}
    seasonality['timeUnit']='HOURS'
    seasonality['periodLength']=24
    data['seasonality']=seasonality
    time_series_data = json.dumps(data)
    print('\nPreparing the Extracted Measurements as per Timeseries API specification.')
    return time_series_data,pd.DatetimeIndex(datetimes);
  
def run_the_predictions_for_next_day(uploaded_model):
    # Run the Inference for the next day with 48 numbers
    #Preparing input csv for next day
    next_day_date=END_DATE+timedelta(days=1)
    
    print('The ##'+uploaded_model + '## is now available for Zementis microservice')
    print('\nRunning the Predictions for the Next day '+str(next_day_date)+'i.e 12 future values')
    
    #Calling timeseries for predictions
    url = tenant_url+'/service/zementis/apply/'+uploaded_model
    prediction_response=requests.get(url = url, params = 'record={"h":12}', auth=(user_name, password), verify=True) 
    
    if prediction_response.ok:
        prediction_response=json.loads(prediction_response.text)
    else:
        print(get_exception_msg(prediction_response.text));
        return
    
    training_data=read_csv('temp/input_data_for_training.csv')
    num_rows=len(training_data.index)
    last_reading_date=training_data.iloc[num_rows-1][0]
    last_reading_date=last_reading_date.split(' ')

    eDate = pdt.strptime(last_reading_date[0]+'T'+last_reading_date[1], "%Y-%m-%dT%H:%M:%S")
    
    prd=list()
    prd.append(training_data.iloc[num_rows-1][1])
    predictions_dict= prediction_response["outputs"][0]
    for key in range(1,13):
        prd.append(predictions_dict["predicted_value"].get(str(key)))
    
    
    datetimes = []
    for _ in prd:
        datetimes.append(pd.Timestamp(eDate))
        eDate = eDate+timedelta(hours=2)
    df=pd.DataFrame(data=prd,index=pd.DatetimeIndex(datetimes))
    df.index.name='Date'
    df.to_csv('temp/predict.csv',header=[ 'predicted_value'])
    

def plot_the_predicted_values():
    
    from matplotlib import pyplot
    import matplotlib 
    #%matplotlib inline 
    series = read_csv('temp/input_data_for_training.csv', header=0, index_col=0, parse_dates=True, squeeze=True)
    series.plot()
    series1 = read_csv('temp/predict.csv', header=0, index_col=0, parse_dates=True, squeeze=True)
    series1.plot()
    
    
    testseries =read_csv('temp/predict.csv',skiprows=[1,1])
    testseries=testseries.sort_values(by=["predicted_value"])
    print(testseries)
    
    peak_hour=testseries.iloc[0]["Date"]
    peak_consumption=testseries.iloc[0]["predicted_value"]
    
    row_count=len(testseries)
    min_hour=testseries.iloc[row_count-1]["Date"]
    min_consumption=testseries.iloc[row_count-1]["predicted_value"]
    
    print('\n The Peak Consumption observed at '+str(peak_hour)+' hours and its predicted value :: '+str(peak_consumption) )
    print('\n The Minimum Consumption observed at '+str(min_hour)+' hours and its predicted value :: '+str(min_consumption) )
    pyplot.show()
    
    

def draw_measurements_train_model():
    # Replace with the correct URL
    URL = tenant_url+'/measurement/measurements'

    PARAMS = {'dateTo':str(END_DATE)+"T23:59:00+"+tz_zone_info,
             'dateFrom':str(START_DATE)+"T00:00:00+"+tz_zone_info,
             'source':deviceID, #'12044928'
             'withTotalPages':'true',
             'pageSize':'2000'} 
    print('\nCollecting ## c8y_Flow ## measurements of the device ## '+ deviceID +' ## for the duration of - '+str(START_DATE)+' and '+str(END_DATE) +' from Cumulocity')

    response_content = requests.get(url = URL, params = PARAMS, auth=(user_name, password), verify=True) 

    # For successful API call, response code will be 200 (OK)
    if response_content.ok:
        jContent=json.loads(response_content.content)
        extract_measurements(response_content.content)
        if 'next' in jContent:
            nextPage=jContent['next']
            while nextPage != None and len(nextPage) != 0:
                response_content=get_measurement_request(nextPage)
                extract_measurements(response_content.content)
                jsonData=json.loads(response_content.content)
                if 'next' in jsonData:
                    nextPage=jsonData['next']
                else:
                    nextPage=''
    else:
        response_content.raise_for_status();
    
    if len(c8y_Flow)==0:
        print("\nc8Y_Flow values are empty.Please follow the setup instructions before running the script.")
        return
    print('\nExtracted ## c8y_Flow ## Measurementsof the device ## '+deviceID +' ##')
    
    #Preparing the time series data for training
    time_series_data_for_training,dp=prepare_time_series_data_for_training()
    print('\nThe following is the Input given to time series model API for training to get the besfit model\n')
    print(time_series_data_for_training)

    postURL=tenant_url+"/service/zementis/timeseries"
    post_resp=requests.post(url=postURL,data=time_series_data_for_training,headers = {'content-type': 'application/json'},auth=(user_name, password),verify=True)
    if not post_resp.ok:
        print('\n'+str(get_exception_msg(post_resp.text)));
        return

    resp_map=json.loads(post_resp.content)
    uploaded_model = resp_map['modelName']

    print('\nThe TimeSeries Model generated by Nyoka Microservice--'+uploaded_model+'.Zementis microservice is waiting for it.')

    model_uploaded_status_url= resp_map['statusUrl']

    status_resp =requests.get(url=tenant_url+model_uploaded_status_url,auth=(user_name, password),verify=True)

    status_resp_map = json.loads(status_resp.content)

    while 'status' in status_resp_map and status_resp_map['status'] == 'IN_PROGRESS':
        print('\n'+uploaded_model + ' Model is not yet avaialble to Zementis Micro Service.....\n')
        time.sleep(50)
        status_resp =requests.get(url=tenant_url+model_uploaded_status_url,auth=(user_name, password),verify=True)
        status_resp_map = json.loads(status_resp.content)

    run_the_predictions_for_next_day(uploaded_model)

    plot_the_predicted_values()

def main():
    draw_measurements_train_model()
    if os.path.exists('temp'):
        shutil.rmtree('temp')

main()