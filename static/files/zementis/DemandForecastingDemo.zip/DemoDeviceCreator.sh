c_url=$(awk -F "=" '/c_url/ {print $2}' ./CONFIG.INI)
c_user=$(awk -F "=" '/c_user/ {print $2}' ./CONFIG.INI)
c_pass=$(awk -F "=" '/c_pass/ {print $2}' ./CONFIG.INI)
echo
echo "#####################################"
echo "#    Registering new demo device    #"
echo "#####################################"
curl --user ${c_user}:${c_pass} -X POST "${c_url}/inventory/managedObjects" -H "accept: application/json" -H "Content-Type: application/json" \
--data '{"name": "DemandForecastDemoDevice", "c8y_IsDevice": {}, "myDemoDevice":{}, "c8y_SupportedMeasurements": ["c8y_Flow"]}'
echo
echo
echo "##############################################################################################################"
echo "#  Registered a demo device with the name 'DemandForecastDemoDevice' and its measurement 'c8y_Flow'#"
echo "##############################################################################################################"

