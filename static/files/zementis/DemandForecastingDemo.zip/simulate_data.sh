#!/bin/bash
input="./input_data.csv"
c_url=$(awk -F "=" '/c_url/ {print $2}' ./CONFIG.INI)
c_user=$(awk -F "=" '/c_user/ {print $2}' ./CONFIG.INI)
c_pass=$(awk -F "=" '/c_pass/ {print $2}' ./CONFIG.INI)
c_device_source=$(awk -F "=" '/c_device_source/ {print $2}' ./CONFIG.INI)

tail -n +2 "$input" | while IFS=',' read -r f1 f2
do 
	dt=$f1
	val=$f2
	date="${dt}+05:30"
	tm=${date:11}
	dtt=${date:0:10}
	strdt="${dtt}T${tm}"
	#echo '{"measurements":[{"time": "'$strdt'","source": {"id": "'$c_device_source'"},"type": "c8y_Flow","c8y_Flow": {"F": {"unit": "psi","value": '$val'}}}]}'
	curl --user $c_user:$c_pass -X POST $c_url"/measurement/measurements" -H "accept: application/vnd.com.nsn.cumulocity.measurementCollection+json" -H "Content-Type: application/json" --data '{"measurements":[{"time": "'$strdt'","source": {"id": "'$c_device_source'"},"type": "c8y_Flow","c8y_Flow": {"F": {"unit": "psi","value": '$val'}}}]}'
done 
