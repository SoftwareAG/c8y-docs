'''
This is to simulate live sensor from a data file
'''
import configparser
import csv
import requests, json
from requests.auth import HTTPBasicAuth
from datetime import datetime, timedelta
import pandas as pd


# Define the data path for config file
configFile='../Data/CONFIG.json'

# Load config
getConfig=json.loads(open(configFile,'r').read())


# c8y info
c8y_headers={'accept': 'application/vnd.com.nsn.cumulocity.measurementCollection+json'}
c_url=getConfig['c_url']
c_measurements_endpoint=c_url+"/measurement/measurements"

c_auth = HTTPBasicAuth(getConfig['c_user'], getConfig['c_pass'])
headers = {
  'Content-Type': 'application/json',
  'Accept': 'application/vnd.com.nsn.cumulocity.measurement+json'

}

c8y_device=getConfig['c_device_source']

DATE_FROM = (datetime.utcnow() - timedelta(minutes=3)).isoformat() + 'Z'
c_params={"source":c8y_device,"pageSize":"2000","dateFrom":DATE_FROM}


# get first page of json data measurements from cumulocity
r=requests.get(c_measurements_endpoint,params=c_params, auth=c_auth) 
print("Data source: \t"+r.url)
print("Status code: \t"+str(r.status_code))

json_doc = r.json()

# take last record
last_record=json_doc['measurements'][-1]	

record = {}
for i in range(1,22):
	record["s_"+str(i)] = last_record['s_'+str(i)]['F']['value']

# call zementis with last measurement data
request_endpoint = c_url+'/service/zementis/apply/RULRFRegressor?record='+json.dumps(record)
prediction_response = requests.get(request_endpoint, auth=c_auth)
print("Prediction: \t" + str(prediction_response.json()))
prediction = prediction_response.json()["outputs"][0]["predicted_RUL"]
# send prediction to device

payload = json.dumps({"c8y_predicted_rul": {"F": {"unit": "NA","value": prediction}},
						"time": datetime.utcnow().isoformat(),
						"source": {
                        "id": getConfig['c_device_pred']
                          },
                          "type": "c8y_sensor"
                        })
response = requests.post(c_measurements_endpoint,auth=c_auth, headers=headers, data=payload)
print("Status code: \t" + str(response.status_code))
print("Response: \t" + str(response.json()))





