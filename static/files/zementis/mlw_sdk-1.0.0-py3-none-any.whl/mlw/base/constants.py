
SERVICE_PATH = "/service/mlw"

class URLS:
    class MLW:
        HEALTH = "/health"
        PROJECTS = "/projects"
        RESOURCES = "/projects/{}/resources"
        DOWNLOAD_RESOURCE = "/download/{}/Data/{}"

class ERRORS:
    PROJECT_NOT_FOUND = "Project object not created. Project name \"{}\" not found in MLW. "

