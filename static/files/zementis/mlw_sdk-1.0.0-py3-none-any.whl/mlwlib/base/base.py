"""
This module contains MLW HTTPClient class and its related functions
"""

import getpass
import requests
from requests.auth import HTTPBasicAuth
from mlwlib.base.constants import SERVICE_PATH

class HTTPClient():
    """
    HTTPClient class, contains HTTP configuration methods for MLW application.

    """
    def __init__(self, c8y_base_url):
        """ 
        init method of HTTPClient class
        
        :param c8y_base_url: url of MLW tenant
        :type c8y_base_url: String
        """
        self.__session = requests.session()
        self.__session.hooks['response'] = [self.check_for_errors]
        self.configure(c8y_base_url)

    def check_for_errors(self, resp, *args, **kwargs):
        resp.raise_for_status()
    
    def configure(self, c8y_base_url):
        """ 
        configure method of HTTPClient class
        
        :param c8y_base_url: url of MLW tenant
        :type c8y_base_url: String
        """
        self.__c8y_base_url = c8y_base_url
        self.__session.auth = HTTPBasicAuth(input('Enter username:  '), getpass.getpass(prompt='Enter password: '))

    def fetch(self, method: str, path: str, **kwargs):
        return getattr(self.__session, method.lower())(f"{self.__c8y_base_url}{SERVICE_PATH}{path}", **kwargs)
