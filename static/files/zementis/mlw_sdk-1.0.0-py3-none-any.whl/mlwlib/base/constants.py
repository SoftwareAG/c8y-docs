
SERVICE_PATH = "/service/mlw"

class URLS:
    class MLW:
        HEALTH = "/health"
        PROJECTS = "/projects"
        RESOURCES = "/projects/{}/resources"
        DOWNLOAD_RESOURCE = "/download/{}/Data/{}"


