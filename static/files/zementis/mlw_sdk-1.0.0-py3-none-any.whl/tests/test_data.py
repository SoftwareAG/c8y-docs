import pandas as pd

PROJECT_GET_RESPONSE = {
    "data": [
        {
            "id": "9f3e739a71c7450094591221d33f8bde",
            "name": "Test Project1",
            "description": "test Project 1",
            "properties": [],
            "isModified": True,
            "isFreeze": False,
            "isFreezeProjectPull": False,
            "selectedVersion": "",
            "versions": [],
            "resourcesCount": {
                "data": 0,
                "model": 0,
                "code": 0,
                "workflow": 0,
                "pipeline": 0,
                "nn-designer": 0,
                "totalCount": 0
            },
            "downloadUrl": None
        },
        {
            "id": "355154b676db4986b8e8cd2bfd823987",
            "name": "Test Project2",
            "description": "test Project 2",
            "properties": [],
            "isModified": True,
            "isFreeze": False,
            "isFreezeProjectPull": False,
            "selectedVersion": "",
            "versions": [],
            "resourcesCount": {
                "data": 0,
                "model": 0,
                "code": 0,
                "workflow": 0,
                "pipeline": 0,
                "nn-designer": 0,
                "totalCount": 0
            },
            "downloadUrl": None
        }
    ]
}

DUMMY_PROJECT_LIST_JSON = {
    'projectList': [
        {
            'id': '9f3e739a71c7450094591221d33f8bde',
            'name': 'Test Project1'
        },
        {
            'id': '355154b676db4986b8e8cd2bfd823987',
            'name': 'Test Project2'
        }
    ]
}

DUMMY_PROJECT_LIST_DF = pd.DataFrame(DUMMY_PROJECT_LIST_JSON)

DUMMY_PROJECT_LIST_JSON_ALL = {
    'projectList': [
        {
            "id": "9f3e739a71c7450094591221d33f8bde",
            "name": "Test Project1",
            "description": "test Project 1",
            "properties": [],
            "isModified": True,
            "isFreeze": False,
            "isFreezeProjectPull": False,
            "selectedVersion": "",
            "versions": [],
            "resourcesCount": {
                "data": 0,
                "model": 0,
                "code": 0,
                "workflow": 0,
                "pipeline": 0,
                "nn-designer": 0,
                "totalCount": 0
            },
            "downloadUrl": None
        },
        {
            "id": "355154b676db4986b8e8cd2bfd823987",
            "name": "Test Project2",
            "description": "test Project 2",
            "properties": [],
            "isModified": True,
            "isFreeze": False,
            "isFreezeProjectPull": False,
            "selectedVersion": "",
            "versions": [],
            "resourcesCount": {
                "data": 0,
                "model": 0,
                "code": 0,
                "workflow": 0,
                "pipeline": 0,
                "nn-designer": 0,
                "totalCount": 0
            },
            "downloadUrl": None
        }
    ]
}

DUMMY_PROJECT_LIST_DF_ALL = pd.DataFrame(DUMMY_PROJECT_LIST_JSON_ALL)
