from requests import Session
from requests.auth import HTTPBasicAuth
from unittest.mock import Mock, patch
from mlw.mlw import MLWClient, Project
from mlw.base.base import HTTPClient
from .test_data import PROJECT_GET_RESPONSE, DUMMY_PROJECT_LIST_JSON, DUMMY_PROJECT_LIST_DF, DUMMY_PROJECT_LIST_JSON_ALL, DUMMY_PROJECT_LIST_DF_ALL


# @patch.object(Session, 'get')
# def test_foo(mock_get):
#     mock_get.return_value = 'bar' 

def mocked_requests_get(*args, **kwargs):
    class MockResponse:
        def __init__(self, text, status_code):
            self.text = text
            self.status_code = status_code

        def json(self):
            return self.text

    return MockResponse(PROJECT_GET_RESPONSE, 200)

def mocked_http_client(*args, **kwargs):
    class MockClient:
        def __init__(self):
            self.c8y_base_url = "dummy_c8y_tenant_url"
            self.__auth = HTTPBasicAuth("testuser", "testpass")
            # self.request_session = requests.session()
            # self.request_session.auth = self.__auth
    return MockClient()

# @patch('get', return_value = Mock(status_code=201, text=PROJECT_GET_RESPONSE))
@patch.object(Session, 'get')
@patch.object(HTTPClient, mocked_http_client())
def test_list_projects(mock_get):
    mock_get.return_value = mocked_requests_get()
    # project_list_json = MLWClient("dummy_c8y_tenant_url").list_projects(show_json=True, show_all_attributes=False)
    project_list_json = list_projects(show_json=True, show_all_attributes=False)
    assert project_list_json == DUMMY_PROJECT_LIST_JSON

# def test_project_object():
#     pass

# def test_get_project_id():
#     pass

# def test_list_resources():
#     pass

# def test_upload_resource():
#     pass

# def test_download_resource():
#     pass