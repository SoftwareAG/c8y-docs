from mlwlib.mlw import mlwfunctions

def test_upload_resource():
    pass

def test_download_resource():
    pass