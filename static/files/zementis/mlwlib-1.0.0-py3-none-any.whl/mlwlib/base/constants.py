BYPASS_PROXY = {"http":"","https":"","ftp":""}

class URLS:
    class MLW:
        PROJECTS = "{}/service/mlw/projects"
        RESOURCES = "{}/service/mlw/projects/{}/resources"
        DOWNLOAD_RESOURCE = "{}/service/mlw//download/{}/Data/{}"
        UPLOAD_RESOURCE = "{}/service/mlw/projects/{}/resources"


